class MyLib {
  constructor(options) {
    this.state = {
      backgroundColor: options.backgroundColor,
    };
    this.input = document.getElementById("inputFile");
    this.dataTable = document.getElementById("dataTable");
    this.isFormToReductDataOpen = false;
    this.selectedRowBeforChangingData = "";
    this.data;
    this.jsonKeys;
    this.numberOfCols = 0;
    this.input.addEventListener("change", this.downloadingJSONFile.bind(this));
    this.dataTable.addEventListener(
      "click",
      this.findClickAndReductTable.bind(this)
    );
    document
      .getElementById("addOneRowId")
      .addEventListener("click", this.addNewRow.bind(this));
  }

  downloadingJSONFile(event) {
    const file = this.input.files[0];
    const reader = new FileReader();
    reader.onload = function (event) {
      this.data = JSON.parse(reader.result);
      this.jsonKeys = Object.keys(this.data[0]);
      this.renderJSON(this.data).bind(this);
    }.bind(this);
    reader.readAsText(file);
  }

  renderJSON(data) {
    let dataForRender,
      tableForRender = "";

    for (let j = 0; j < this.jsonKeys.length; j++) {
      tableForRender += `<th data-number>${this.jsonKeys[j]}</th>`;
    }
    dataForRender = `<tr>${tableForRender}</tr>`;
    tableForRender = "";

    for (let i = 0; i < this.data.length; i++) {
      let tempLine = "";
      for (let j = 0; j < this.jsonKeys.length; j++) {
        if (j === this.jsonKeys.length - 1) {
          tempLine += `<td class="lastTd" data-row="${i}" data-col="${j}">${
            this.data[i][this.jsonKeys[j]]
          }<div class="wrapForReductAndDelButtons"><button class="pen"></button><button class="deleteRow"></button></div></td>`;
        } else {
          tempLine += `<td data-row="${i}" data-col="${j}">${
            this.data[i][this.jsonKeys[j]]
          }</td>`;
        }
      }
      tableForRender += `<tr>${tempLine}</tr>`;
    }
    dataForRender = `
      <caption>
        Данные из файла
      </caption>
      ${dataForRender}
      ${tableForRender}`;
    document.getElementsByClassName(
      "wrapper"
    )[0].style.backgoundColor = this.state.backgroundColor;
    this.dataTable.innerHTML = dataForRender;
  }

  findClickAndReductTable() {
    if (this.isFormToReductDataOpen) return;

    let row = "";
    const thAll = document.querySelectorAll("th");
    const td = event.target.closest("td");
    const deleteButton = event.target.closest(".deleteRow");
    if (deleteButton) {
      this.deleteRow(td.getAttribute("data-row")).bind(this);
    } else {
      if (!td || !this.dataTable.contains(td)) return;
      this.isFormToReductDataOpen = true;
      this.selectedRowBeforChangingData = td.parentNode.innerHTML;
      const selectedRow = td.parentNode;
      const rowAttribute = td.getAttribute("data-row");

      for (let j = 0; j < this.jsonKeys.length; j++) {
        row += `<td><input type="text" name="${j}" class="inputFormReduct" value="${
          this.data[rowAttribute][this.jsonKeys[j]]
        }"/></td>`;
        this.numberOfCols = j;
      }
      //   const dataForInputRow = `<form id="formReductRow" action="#">${row}
      //       <div class="wrapperButtons">
      //         <button type="submit" class="iconsGeneralRulls saveIcon"></button>
      //         <button type="reset" class="iconsGeneralRulls cancelIcon"></button>
      //       </div>
      //   </form>
      // `;
      // for (let i = 0; i < selectedRow.childNodes.length; i++) {
      // selectedRow.childNodes[i].style.padding = 0 + "px";
      // selectedRow.childNodes[i].style.backgoundColor = "green";
      // console.log(selectedRow.childNodes[i]);

      selectedRow.classList.add("active");
      selectedRow.innerHTML = row;
      // selectedRow.style.height = height + "px";
      // selectedRow.style.width = width + "px";
      // document.getElementById("formReductRow").style.height = height + "px";
      // document.getElementById("formReductRow").style.width =
      //   width - numberOfCols + "px";

      const inputs = document.getElementsByClassName("inputFormReduct");
      const inputsValues = [];
      // for (let i = 0; i < inputs.length; i++) {
      //   // inputs[i].style.width = thAll[i].clientWidth - 1 + "px";
      //   inputsValues[i] = inputs[i].value;
      // }

      document
        .getElementById("formToInputTableData")
        .addEventListener("submit", (e) => {
          e.preventDefault();
          e.stopPropagation();

          for (let i = 0; i < inputs.length; i++) {
            inputsValues[i] = e.srcElement[i].value;
          }
          this.onClickSubmitInFormReductRow(rowAttribute, inputsValues);
        });

      document
        .getElementById("formToInputTableData")
        .addEventListener("reset", (e) => {
          e.preventDefault();
          e.stopPropagation();
          this.onClickResetInFormReductRow();
        });
    }
  }

  deleteRow(numberOfRow) {
    this.data.splice(numberOfRow, 1);
    this.renderJSON(this.data);
  }

  addNewRow() {
    if (this.data) {
      this.data.push({});
      const dataLength = this.data.length;
      for (let i = 0; i < this.jsonKeys.length; i++) {
        this.data[dataLength - 1][this.jsonKeys[i]] = "...enter value...";
      }
      this.renderJSON(this.data);
    } else alert("download file first");
  }
}

new MyLib({
  backgroundColor: "red",
});
