"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var MyLib =
/*#__PURE__*/
function () {
  function MyLib(options) {
    _classCallCheck(this, MyLib);

    this.state = {
      backgroundColor: options.backgroundColor
    };
    this.input = document.getElementById("inputFile");
    this.dataTable = document.getElementById("dataTable");
    this.isFormToReductDataOpen = false;
    this.selectedRowBeforChangingData = "";
    this.data;
    this.jsonKeys;
    this.numberOfCols = 0;
    this.input.addEventListener("change", this.downloadingJSONFile.bind(this));
    this.dataTable.addEventListener("click", this.findClickAndReductTable.bind(this));
    document.getElementById("addOneRowId").addEventListener("click", this.addNewRow.bind(this));
  }

  _createClass(MyLib, [{
    key: "downloadingJSONFile",
    value: function downloadingJSONFile(event) {
      var file = this.input.files[0];
      var reader = new FileReader();

      reader.onload = function (event) {
        this.data = JSON.parse(reader.result);
        this.jsonKeys = Object.keys(this.data[0]);
        this.renderJSON(this.data).bind(this);
      }.bind(this);

      reader.readAsText(file);
    }
  }, {
    key: "renderJSON",
    value: function renderJSON(data) {
      var dataForRender,
          tableForRender = "";

      for (var j = 0; j < this.jsonKeys.length; j++) {
        tableForRender += "<th data-number>".concat(this.jsonKeys[j], "</th>");
      }

      dataForRender = "<tr>".concat(tableForRender, "</tr>");
      tableForRender = "";

      for (var i = 0; i < this.data.length; i++) {
        var tempLine = "";

        for (var _j = 0; _j < this.jsonKeys.length; _j++) {
          if (_j === this.jsonKeys.length - 1) {
            tempLine += "<td class=\"lastTd\" data-row=\"".concat(i, "\" data-col=\"").concat(_j, "\">").concat(this.data[i][this.jsonKeys[_j]], "<div class=\"wrapForReductAndDelButtons\"><button class=\"pen\"></button><button class=\"deleteRow\"></button></div></td>");
          } else {
            tempLine += "<td data-row=\"".concat(i, "\" data-col=\"").concat(_j, "\">").concat(this.data[i][this.jsonKeys[_j]], "</td>");
          }
        }

        tableForRender += "<tr>".concat(tempLine, "</tr>");
      }

      dataForRender = "\n      <caption>\n        \u0414\u0430\u043D\u043D\u044B\u0435 \u0438\u0437 \u0444\u0430\u0439\u043B\u0430\n      </caption>\n      ".concat(dataForRender, "\n      ").concat(tableForRender);
      document.getElementsByClassName("wrapper")[0].style.backgoundColor = this.state.backgroundColor;
      this.dataTable.innerHTML = dataForRender;
    }
  }, {
    key: "findClickAndReductTable",
    value: function findClickAndReductTable() {
      var _this = this;

      if (this.isFormToReductDataOpen) return;
      var row = "";
      var thAll = document.querySelectorAll("th");
      var td = event.target.closest("td");
      var deleteButton = event.target.closest(".deleteRow");

      if (deleteButton) {
        this.deleteRow(td.getAttribute("data-row")).bind(this);
      } else {
        if (!td || !this.dataTable.contains(td)) return;
        this.isFormToReductDataOpen = true;
        this.selectedRowBeforChangingData = td.parentNode.innerHTML;
        var selectedRow = td.parentNode;
        var rowAttribute = td.getAttribute("data-row");

        for (var j = 0; j < this.jsonKeys.length; j++) {
          row += "<td><input type=\"text\" name=\"".concat(j, "\" class=\"inputFormReduct\" value=\"").concat(this.data[rowAttribute][this.jsonKeys[j]], "\"/></td>");
          this.numberOfCols = j;
        } //   const dataForInputRow = `<form id="formReductRow" action="#">${row}
        //       <div class="wrapperButtons">
        //         <button type="submit" class="iconsGeneralRulls saveIcon"></button>
        //         <button type="reset" class="iconsGeneralRulls cancelIcon"></button>
        //       </div>
        //   </form>
        // `;
        // for (let i = 0; i < selectedRow.childNodes.length; i++) {
        // selectedRow.childNodes[i].style.padding = 0 + "px";
        // selectedRow.childNodes[i].style.backgoundColor = "green";
        // console.log(selectedRow.childNodes[i]);


        selectedRow.classList.add("active");
        selectedRow.innerHTML = row; // selectedRow.style.height = height + "px";
        // selectedRow.style.width = width + "px";
        // document.getElementById("formReductRow").style.height = height + "px";
        // document.getElementById("formReductRow").style.width =
        //   width - numberOfCols + "px";

        var inputs = document.getElementsByClassName("inputFormReduct");
        var inputsValues = []; // for (let i = 0; i < inputs.length; i++) {
        //   // inputs[i].style.width = thAll[i].clientWidth - 1 + "px";
        //   inputsValues[i] = inputs[i].value;
        // }

        document.getElementById("formToInputTableData").addEventListener("submit", function (e) {
          e.preventDefault();
          e.stopPropagation();

          for (var i = 0; i < inputs.length; i++) {
            inputsValues[i] = e.srcElement[i].value;
          }

          _this.onClickSubmitInFormReductRow(rowAttribute, inputsValues);
        });
        document.getElementById("formToInputTableData").addEventListener("reset", function (e) {
          e.preventDefault();
          e.stopPropagation();

          _this.onClickResetInFormReductRow();
        });
      }
    }
  }, {
    key: "deleteRow",
    value: function deleteRow(numberOfRow) {
      this.data.splice(numberOfRow, 1);
      this.renderJSON(this.data);
    }
  }, {
    key: "addNewRow",
    value: function addNewRow() {
      if (this.data) {
        this.data.push({});
        var dataLength = this.data.length;

        for (var i = 0; i < this.jsonKeys.length; i++) {
          this.data[dataLength - 1][this.jsonKeys[i]] = "...enter value...";
        }

        this.renderJSON(this.data);
      } else alert("download file first");
    }
  }]);

  return MyLib;
}();

new MyLib({
  backgroundColor: "red"
});