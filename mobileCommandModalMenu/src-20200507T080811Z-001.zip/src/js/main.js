$('.mobile-menu').mm({
    animationSpeed: 500
});